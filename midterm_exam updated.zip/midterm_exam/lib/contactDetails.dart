import 'package:flutter/material.dart';

class contactDetails extends StatelessWidget {
  const contactDetails ({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        leading: IconButton(
        icon: Icon (Icons.arrow_back), 
        onPressed: () { Navigator.pop(context);})
      ),

      backgroundColor: Colors.white,

      body: SingleChildScrollView(
        child: Column(
          
          children: [
            Center(
              child: Column(
                children: [
                  SizedBox(height: 20),

                  CircleAvatar(
                        radius: 40.0,
                        backgroundImage: AssetImage('assets/skye.jpg'),
                  ),

                  Text( 
                    "Chrissandra Bautista",
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'palatino',
                    )
                  ),

                  const SizedBox(height: 20),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  details("+63 976 456 2314", Icons.call, Icons.message),
                  const SizedBox(height: 10),
                  Text("Call history", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),),
                  callHistory("Apr 27, 14:16", "+639654367513", "Didn't connect"),
                  callHistory("Apr 20, 10:35", "+639654367513", "Rang 5 times"),
                  callHistory("Mar 05, 19:23", "+639654367513", "Outgoing 15 min 12 sec"),
                  callHistory("Feb 12, 08:03", "+639654367513", "Incoming 30 sec"),
    ]
  )

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget details(String title, IconData icon1, IconData icon2) {
  return Padding(padding: const EdgeInsets.all(10),
  child: 
    Row (
    children: [
    Text(
      title,
      style: const TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        fontFamily: 'palatino',
      )
    ),
    SizedBox(width: 580),
    Row (
      children: [
        Icon(icon1, color: Colors.blue),
        Icon(icon2, color: Colors.blue)
      ],
    ),
    ]
    )
  );
}

Widget callHistory(String title1, String title2, String title3) {
  return Padding(
    padding: const EdgeInsets.all(10),

    child: Row (
      children: [

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title1,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.normal,
                fontFamily: 'palatino',
              )
            ),

            Text(
              title2,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                fontFamily: 'palatino',
              )
            )

          ],
        ),

        const SizedBox(width: 650),

        Text(
          title3,
          style: const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          fontFamily: 'palatino',
          )
        )
      ],
    )
  );
}

