import 'package:flutter/material.dart';
import 'package:midterm_exam/contactDetails.dart';
import 'package:midterm_exam/addContact.dart';
void main() {
  runApp(const MyApp()); // launches flutter app & sets up widget tree 
}

class MyApp extends StatelessWidget {
  const MyApp({super.key}); // to access root app

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      
      home: const contactListPage(),
    );
  }
}

class contactListPage extends StatelessWidget {
  const contactListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contacts'),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            contactList(context),
          ],
          )
      )
    );
  }
}

Widget contactList (BuildContext context) {
  return Column(
    children: [
      contacts(Icons.person,"Chrissandra Bautista", "+63 976 456 2314", () {Navigator.push(context, MaterialPageRoute(builder: (context)=> contactDetails()));}),
      contacts(Icons.person,"Josh Nimo","+63 990 412 5438", () {}),
      contacts(Icons.person,"Shelou Asaria", "+63 976 456 9067", () {}),
      contacts(Icons.person,"Ace Advincula", "+63 921 000 2314", () {}),
      contacts(Icons.person,"Crislyn Delgado", "+63 991 067 0314", () {}),
      contacts(Icons.person,"Airene Tungol", "+63 921 740 2314", () {}),
      contacts(Icons.person,"James Legado", "+63 901 097 333", () {}),
      contacts(Icons.person,"Kharl Almonguerra", "+63 922 121 2314", () {}),
      contacts(Icons.person,"Vince Carabuena", "+63 901 906 2314", () {}),
      contacts(Icons.person,"Errol De Pedro", "+63 965 000 4230", () {}),

      addButton(Icons.add,() {Navigator.push(context, MaterialPageRoute(builder: (context)=> addContact()));})
    ],
  );
}

Widget contacts(IconData icon, String title1, String title2, VoidCallback onTap) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10),
    child: Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 231, 231, 231),
        borderRadius: BorderRadius.circular(10),
      ),

      child: ListTile(
        leading: Icon(Icons.person, size: 20),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title1,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.normal,
                fontFamily: 'palatino',
              )
            ),

            Text(
              title2,
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                fontFamily: 'palatino',
              )
            )
      ],
      ), 
      trailing: const Icon(Icons.phone, size: 20),
      onTap: onTap
        )
      )
    );
}

Widget addButton(IconData icon, VoidCallback onTap) {
  return Padding(
    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 200),
    child: Container(
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 85, 187, 201),
        borderRadius: BorderRadius.circular(10),
      ),

      child: ListTile(
        title: Text ("Add Contacts"),
        leading: Icon(icon, color: const Color.fromARGB(255, 0, 0, 0)),
        onTap: onTap,
      )
    )
  );
}
