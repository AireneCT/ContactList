import 'package:flutter/material.dart';

class addContact extends StatefulWidget {

  @override
  _addContactState createState() => _addContactState ( //allows the widget to update dynamically when the state changes

  );
}

class _addContactState extends State <addContact> { //controls the UI updates
  final TextEditingController fnameController = TextEditingController(); //Manages text input fields for user details
  final TextEditingController lnameController= TextEditingController();
  final TextEditingController numberController = TextEditingController();
  String selectedGender = '';

  @override
  Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(
            title: Text("Add"),
            leading: IconButton(
              icon: Icon (Icons.arrow_back), 
              onPressed: () { Navigator.pop(context);})),
           body: SingleChildScrollView(
           padding: EdgeInsets.all(20.0),
           child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              buildTextField("First Name", fnameController),
              buildTextField("Last Name", lnameController),
              buildTextField("Phone Number", numberController),

              const SizedBox(height: 20.0),
              ]
            )
          )
        );
  }
  Widget buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: TextField(controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder()
      )
      )
    );
  }
  void saveData() {
    String fname = fnameController.text;
    String lname = lnameController.text;
    String num = numberController.text;

    print(
      "Name: $fname \n"
      "Date of Birth: $lname \n"
      "Job: $num \n"
    );
  }


}